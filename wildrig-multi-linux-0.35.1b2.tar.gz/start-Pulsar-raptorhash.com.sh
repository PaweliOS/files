#!/bin/bash

while true
do
./wildrig-multi --algo curvehash --url stratum+tcp://na.raptorhash.com:6904 --user PRmpjh18kH2RpzZPM4UD4W94BWSgkFPJWe --pass x
sleep 5
done

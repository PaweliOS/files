#!/bin/bash

while true
do
./wildrig-multi --algo vprogpow --url stratum+tcp://vbk-reb0rn.ddns.net:8502 --user V9yArEZzZdy2XLFZekCN2CFhxBqr8v --pass x
sleep 5
done

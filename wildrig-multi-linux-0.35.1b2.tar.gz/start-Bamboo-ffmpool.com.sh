#!/bin/bash

while true
do
./wildrig-multi --algo pufferfish2 --url stratum+tcp://bmb.ffmpool.com:4444 --user 000CC525FD7DFBD6DBC72956F0AE924CFFC20824ABFD193003 --pass x
sleep 5
done

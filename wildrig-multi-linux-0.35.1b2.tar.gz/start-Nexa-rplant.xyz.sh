#!/bin/bash

while true
do
./wildrig-multi --algo nexapow --url stratum+tcp://stratum-eu.rplant.xyz:7092 --user nqtsq5g5uw05wdm7fv0ughd3459t3v5l26r0r4spfmtyhcjw --pass x
sleep 5
done

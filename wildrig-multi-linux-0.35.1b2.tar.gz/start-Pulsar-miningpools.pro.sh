#!/bin/bash

while true
do
./wildrig-multi --algo curvehash --url stratum+tcp://miningpools.pro:5241 --user PGLaCyoPxTj1VWhyP1XWRKf6EVRkb1Kbnw --pass c=PLSR
sleep 5
done
